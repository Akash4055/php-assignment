<!doctype html>
<html>
	<head><title>Database</title>
	</head>
	<body>
		<?php
			$servername="localhost";
			$username="root";
			$password="root";
			$dbname="sandy";
			
			$f=$_REQUEST['key'];
			
			$conn= new mysqli($servername,$username,$password,$dbname);
			$sql="select * from institute where nm='$f'";
			
			$result=$conn->query($sql);
			if($result->num_rows>0)
			{
				
					Header('Content-type:text/xml');
					echo "<?xml version='1.0' ?>";
					echo "<institute>";
					while($row=$result->fetch_assoc())
						{
							echo "<ID>".$row['id']."</ID>";
							echo "<firstname>".$row['nm']."</firstname>";
							echo "<lastname>".$row['lnm']."</lastname>";
						}
					echo "</institute>";
			}
			$conn->close();
		?>
	</body>
</html>