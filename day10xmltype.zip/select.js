function select_data(str)
 {
	let xfr= new XMLHttpRequest();
	let urls="select.php?"+"key="+str;
	urls=urls+"&ver="+Math.random();
	
		xfr.open("GET",urls);
		xfr.send();
		
		xfr.onreadystatechange=function()
		{
			if(xfr.readyState==4 && xfr.status==200)
			{
				document.getElementById("yl").innerHTML=xfr.responseText;
			}
		}
 }